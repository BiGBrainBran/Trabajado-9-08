package com.narvasoft.agenda.controller;

public interface WebConfig {
}
